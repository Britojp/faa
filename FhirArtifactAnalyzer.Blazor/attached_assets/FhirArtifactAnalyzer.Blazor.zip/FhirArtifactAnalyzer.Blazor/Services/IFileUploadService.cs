namespace FhirArtifactAnalyzer.Blazor.Services
{
    public interface IFileUploadService
    {
        Task UploadFileAsync(Stream fileStream, string fileName);
    }
}
