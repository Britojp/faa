function initializeTabs(tabId) {
    const tabElement = document.getElementById(tabId);
    if (tabElement) {
        const tabButtons = tabElement.querySelectorAll('[data-bs-toggle="tab"]');
        tabButtons.forEach(button => {
            new bootstrap.Tab(button);
        });
    }
}

function clickElementById(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.click();
    }
}